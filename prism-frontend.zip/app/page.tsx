import Link from "next/link";
import Header from "@/components/Header";

const STEPS = [
  {
    n: "01",
    title: "Submit the claim",
    body: "Type it, paste it, or drop a screenshot of a post, forward or headline. PRISM reads the image and finds what is actually being asserted.",
  },
  {
    n: "02",
    title: "Gather the evidence",
    body: "It searches the open web for independent sources, looking for evidence on both sides of the claim, not just what agrees with it.",
  },
  {
    n: "03",
    title: "Read the verdict",
    body: "You get a verdict, an explanation, supporting and contradicting sources with dates, and a plain statement of what could not be established.",
  },
];

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <section className="hero">
          <h1>SEE BEYOND THE CLAIM.</h1>
          <p>Question information. Examine the evidence. Discover what is actually true.</p>
          <Link href="/workspace" className="btn btn-primary btn-lg">
            Start verifying
          </Link>
        </section>

        <section id="how" className="how">
          <h2>How PRISM works</h2>
          <div className="steps">
            {STEPS.map((s) => (
              <div key={s.n} className="step">
                <span className="step-n">{s.n}</span>
                <h3>{s.title}</h3>
                <p>{s.body}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
    </>
  );
}
