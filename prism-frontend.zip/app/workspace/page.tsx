"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Composer from "@/components/Composer";
import EvidenceDashboard from "@/components/EvidenceDashboard";
import Sidebar from "@/components/Sidebar";
import { deleteChat, getChat, listChats, verify } from "@/lib/api";
import type { ChatMessage, ChatSummary } from "@/lib/types";

export default function Workspace() {
  const [chats, setChats] = useState<ChatSummary[]>([]);
  const [chatsLoading, setChatsLoading] = useState(true);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState<{ text: string; images: number } | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  const refreshChats = useCallback(async () => {
    try {
      setChats(await listChats());
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setChatsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshChats();
  }, [refreshChats]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, busy]);

  async function select(id: string) {
    setError(null);
    setMenuOpen(false);
    try {
      const chat = await getChat(id);
      setActiveId(chat.id);
      setMessages(chat.messages);
    } catch (e) {
      setError((e as Error).message);
    }
  }

  function startNew() {
    setActiveId(null);
    setMessages([]);
    setError(null);
    setMenuOpen(false);
  }

  async function remove(id: string) {
    try {
      await deleteChat(id);
      if (id === activeId) startNew();
      await refreshChats();
    } catch (e) {
      setError((e as Error).message);
    }
  }

  async function submit(text: string, files: File[]): Promise<boolean> {
    setBusy(true);
    setError(null);
    setPending({ text, images: files.length });
    try {
      const res = await verify(text, files, activeId);
      setActiveId(res.chat_id);
      setMessages((m) => [...m, res.user_message, res.assistant_message]);
      refreshChats();
      return true;
    } catch (e) {
      setError((e as Error).message);
      return false;
    } finally {
      setBusy(false);
      setPending(null);
    }
  }

  return (
    <div className="workspace">
      <div className={`side-wrap${menuOpen ? " open" : ""}`}>
        <Sidebar
          chats={chats}
          activeId={activeId}
          loading={chatsLoading}
          onNew={startNew}
          onSelect={select}
          onDelete={remove}
        />
      </div>

      <section className="main-pane">
        <div className="mobile-bar">
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => setMenuOpen((v) => !v)}>
            {menuOpen ? "Close" : "History"}
          </button>
        </div>

        <div className="thread">
          {messages.length === 0 && !pending && (
            <div className="empty">
              <h2>What would you like to verify?</h2>
              <p>
                Submit a claim, a screenshot of a post or message, or both. PRISM will search for evidence on both sides
                and show you its sources.
              </p>
            </div>
          )}

          {messages.map((m) =>
            m.role === "user" ? (
              <div key={m.id} className="bubble user">
                {m.content && <p>{m.content}</p>}
                {m.attachments.length > 0 && (
                  <p className="muted small">
                    {m.attachments.length} image{m.attachments.length > 1 ? "s" : ""}: {m.attachments.map((a) => a.name).join(", ")}
                  </p>
                )}
              </div>
            ) : m.result ? (
              <EvidenceDashboard key={m.id} report={m.result} />
            ) : (
              <div key={m.id} className="bubble">
                <p>{m.content}</p>
              </div>
            )
          )}

          {pending && (
            <>
              <div className="bubble user">
                {pending.text && <p>{pending.text}</p>}
                {pending.images > 0 && (
                  <p className="muted small">
                    {pending.images} image{pending.images > 1 ? "s" : ""} attached
                  </p>
                )}
              </div>
              <div className="loading" role="status" aria-live="polite">
                <span className="spinner" /> Reading the claim, searching for evidence and weighing sources. This can take
                up to a minute.
              </div>
            </>
          )}

          {error && (
            <div className="error" role="alert">
              {error}
            </div>
          )}
          <div ref={endRef} />
        </div>

        <Composer busy={busy} onSubmit={submit} />
      </section>
    </div>
  );
}
