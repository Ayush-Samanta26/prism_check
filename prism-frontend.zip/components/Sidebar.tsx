"use client";

import Link from "next/link";
import type { ChatSummary } from "@/lib/types";
import Logo from "./Logo";

interface Props {
  chats: ChatSummary[];
  activeId: string | null;
  loading: boolean;
  onNew: () => void;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
}

export default function Sidebar({ chats, activeId, loading, onNew, onSelect, onDelete }: Props) {
  return (
    <aside className="sidebar">
      <Link href="/" className="brand" aria-label="PRISM home">
        <Logo size={24} />
        <span>PRISM</span>
      </Link>
      <button type="button" className="btn btn-primary new-chat" onClick={onNew}>
        + New check
      </button>
      <div className="side-label">History</div>
      <ul className="history">
        {loading && <li className="muted pad">Loading…</li>}
        {!loading && chats.length === 0 && <li className="muted pad">No checks yet.</li>}
        {chats.map((c) => (
          <li key={c.id} className={c.id === activeId ? "active" : ""}>
            <button type="button" className="hist-item" onClick={() => onSelect(c.id)} title={c.title}>
              {c.title}
            </button>
            <button type="button" className="hist-del" aria-label={`Delete ${c.title}`} onClick={() => onDelete(c.id)}>
              ×
            </button>
          </li>
        ))}
      </ul>
    </aside>
  );
}
