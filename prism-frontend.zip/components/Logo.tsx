/** Optical prism: white beam in, spectrum out. Bold shapes so it reads at 16px. */
export default function Logo({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" role="img" aria-label="PRISM logo">
      <path d="M2 17 L12.5 16" stroke="#F8FAFC" strokeWidth="2.4" strokeLinecap="round" />
      <path d="M16 4 L28 26 H4 Z" fill="#111827" stroke="#3B82F6" strokeWidth="2" strokeLinejoin="round" />
      <path d="M20 16 L30 9" stroke="#60A5FA" strokeWidth="2" strokeLinecap="round" />
      <path d="M20.5 18 L30.5 17" stroke="#2563EB" strokeWidth="2" strokeLinecap="round" />
      <path d="M20 20 L30 25" stroke="#93C5FD" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}
