"use client";

import { useEffect, useMemo, useRef, useState, type ClipboardEvent, type DragEvent, type KeyboardEvent } from "react";

const MAX_IMAGES = 4;
const ACCEPT = ["image/png", "image/jpeg", "image/webp", "image/gif"];

interface Props {
  busy: boolean;
  onSubmit: (text: string, files: File[]) => Promise<boolean>;
}

export default function Composer({ busy, onSubmit }: Props) {
  const [text, setText] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [drag, setDrag] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  const previews = useMemo(() => files.map((f) => URL.createObjectURL(f)), [files]);
  useEffect(() => () => previews.forEach((u) => URL.revokeObjectURL(u)), [previews]);

  function addFiles(list: FileList | File[]) {
    const incoming = Array.from(list);
    const valid = incoming.filter((f) => ACCEPT.includes(f.type));
    const skipped = incoming.length - valid.length;
    setFiles((prev) => {
      const room = MAX_IMAGES - prev.length;
      if (valid.length > room) setNote(`Only ${MAX_IMAGES} images per check.`);
      return [...prev, ...valid.slice(0, Math.max(room, 0))];
    });
    if (skipped > 0) setNote("Only PNG, JPEG, WEBP and GIF images are supported.");
  }

  function onPaste(e: ClipboardEvent) {
    const imgs = Array.from(e.clipboardData.files).filter((f) => f.type.startsWith("image/"));
    if (imgs.length) {
      e.preventDefault();
      addFiles(imgs);
    }
  }

  function onDrop(e: DragEvent) {
    e.preventDefault();
    setDrag(false);
    if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
  }

  async function send() {
    if (busy || (!text.trim() && files.length === 0)) return;
    setNote(null);
    const ok = await onSubmit(text.trim(), files);
    if (ok) {
      setText("");
      setFiles([]);
    }
  }

  function onKey(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  return (
    <div
      className={`composer${drag ? " drag" : ""}`}
      onDragOver={(e) => {
        e.preventDefault();
        setDrag(true);
      }}
      onDragLeave={() => setDrag(false)}
      onDrop={onDrop}
    >
      {files.length > 0 && (
        <ul className="previews">
          {files.map((f, i) => (
            <li key={`${f.name}-${i}`}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={previews[i]} alt={f.name} />
              <button type="button" aria-label={`Remove ${f.name}`} onClick={() => setFiles(files.filter((_, j) => j !== i))}>
                ×
              </button>
            </li>
          ))}
        </ul>
      )}
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        onPaste={onPaste}
        onKeyDown={onKey}
        placeholder="Paste a claim, drop a screenshot, or paste an image from your clipboard…"
        rows={3}
        disabled={busy}
      />
      <div className="composer-row">
        <button type="button" className="btn btn-ghost btn-sm" onClick={() => fileInput.current?.click()} disabled={busy}>
          Attach image
        </button>
        <input
          ref={fileInput}
          type="file"
          accept={ACCEPT.join(",")}
          multiple
          hidden
          onChange={(e) => {
            if (e.target.files) addFiles(e.target.files);
            e.target.value = "";
          }}
        />
        {note && <span className="note">{note}</span>}
        <button type="button" className="btn btn-primary" onClick={send} disabled={busy || (!text.trim() && files.length === 0)}>
          {busy ? "Examining…" : "Verify"}
        </button>
      </div>
    </div>
  );
}
