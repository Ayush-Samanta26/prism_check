import Link from "next/link";
import Logo from "./Logo";

export default function Header() {
  return (
    <header className="site-header">
      <Link href="/" className="brand" aria-label="PRISM home">
        <Logo />
        <span>PRISM</span>
      </Link>
      <nav className="nav">
        <Link href="/#how">How it works</Link>
        <Link href="/workspace" className="btn btn-primary btn-sm">
          Open workspace
        </Link>
      </nav>
    </header>
  );
}
