import type { CitedSource, Report, Verdict } from "@/lib/types";

const LABEL: Record<Verdict, string> = {
  TRUE: "True",
  MOSTLY_TRUE: "Mostly true",
  MIXED: "Mixed",
  MOSTLY_FALSE: "Mostly false",
  FALSE: "False",
  UNVERIFIABLE: "Unverifiable",
};

function fmtDate(iso: string | null) {
  if (!iso) return "Date unknown";
  const d = new Date(iso);
  return isNaN(d.getTime()) ? iso : d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

function host(url: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

function SourceList({ title, items, tone }: { title: string; items: CitedSource[]; tone: "pro" | "con" }) {
  return (
    <section className={`ev-col ev-${tone}`}>
      <h4>
        {title} <span className="count">{items.length}</span>
      </h4>
      {items.length === 0 ? (
        <p className="muted">None cited.</p>
      ) : (
        <ul>
          {items.map((s) => (
            <li key={s.index}>
              <a href={s.url} target="_blank" rel="noopener noreferrer">
                [{s.index}] {s.title || host(s.url)}
              </a>
              <div className="meta">
                {host(s.url)} · {fmtDate(s.published)}
              </div>
              {s.note && <p>{s.note}</p>}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

export default function EvidenceDashboard({ report }: { report: Report }) {
  const pct = Math.round(report.confidence * 100);
  return (
    <article className="evidence">
      <div className="ev-top">
        <span className={`verdict v-${report.verdict}`}>{LABEL[report.verdict]}</span>
        <span className="conf" title="Strength and agreement of the retrieved evidence">
          Evidence confidence {pct}%
        </span>
      </div>

      {report.claim && (
        <div className="ev-block">
          <h4>Claim examined</h4>
          <p>{report.claim}</p>
        </div>
      )}

      <div className="ev-block">
        <h4>Explanation</h4>
        <p>{report.explanation}</p>
      </div>

      <div className="ev-cols">
        <SourceList title="Supporting sources" items={report.supporting} tone="pro" />
        <SourceList title="Contradicting sources" items={report.contradicting} tone="con" />
      </div>

      {report.limitations.length > 0 && (
        <div className="ev-block">
          <h4>Limitations</h4>
          <ul className="plain">
            {report.limitations.map((l, i) => (
              <li key={i}>{l}</li>
            ))}
          </ul>
        </div>
      )}

      {report.sources.length > 0 && (
        <details className="ev-block">
          <summary>All {report.sources.length} sources retrieved</summary>
          <ol className="plain">
            {report.sources.map((s) => (
              <li key={s.index}>
                <a href={s.url} target="_blank" rel="noopener noreferrer">
                  {s.title || host(s.url)}
                </a>
                <span className="meta">
                  {" "}
                  · {host(s.url)} · {fmtDate(s.published)}
                </span>
              </li>
            ))}
          </ol>
        </details>
      )}

      {report.ocr_text && (
        <details className="ev-block">
          <summary>Text read from screenshots</summary>
          <pre className="ocr">{report.ocr_text}</pre>
        </details>
      )}

      <footer className="ev-foot">
        Analysed {fmtDate(report.analyzed_at)} · {report.models.llm} · search: {report.models.search}. Verdicts reflect
        only the sources shown and can be wrong; check them before relying on them.
      </footer>
    </article>
  );
}
