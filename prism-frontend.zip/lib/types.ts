export type Verdict =
  | "TRUE"
  | "MOSTLY_TRUE"
  | "MIXED"
  | "MOSTLY_FALSE"
  | "FALSE"
  | "UNVERIFIABLE";

export interface CitedSource {
  index: number;
  title: string;
  url: string;
  published: string | null;
  note: string;
}

export interface Source {
  index: number;
  title: string;
  url: string;
  published: string | null;
}

export interface Report {
  claim: string;
  verdict: Verdict;
  confidence: number;
  explanation: string;
  supporting: CitedSource[];
  contradicting: CitedSource[];
  sources: Source[];
  limitations: string[];
  ocr_text: string;
  analyzed_at: string;
  models: { llm: string; search: string };
  queries?: string[];
}

export interface Attachment {
  name: string;
  media_type: string;
  size: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  attachments: Attachment[];
  result: Report | null;
  created_at: string;
}

export interface ChatSummary {
  id: string;
  title: string;
  updated_at: string;
}

export interface ChatDetail {
  id: string;
  title: string;
  messages: ChatMessage[];
}

export interface VerifyResponse {
  chat_id: string;
  title: string;
  user_message: ChatMessage;
  assistant_message: ChatMessage;
}
