import type { ChatDetail, ChatSummary, VerifyResponse } from "./types";

const BASE = (process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000").replace(/\/$/, "");

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${BASE}/api${path}`, init);
  } catch {
    throw new Error("Cannot reach the PRISM server. Check that the backend is running.");
  }
  if (!res.ok) {
    let detail = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (typeof body.detail === "string") detail = body.detail;
    } catch {
      /* keep default */
    }
    throw new Error(detail);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

export const listChats = () => request<ChatSummary[]>("/chats");
export const getChat = (id: string) => request<ChatDetail>(`/chats/${id}`);
export const deleteChat = (id: string) => request<void>(`/chats/${id}`, { method: "DELETE" });

export function verify(text: string, files: File[], chatId: string | null) {
  const form = new FormData();
  form.append("text", text);
  if (chatId) form.append("chat_id", chatId);
  files.forEach((f) => form.append("files", f));
  return request<VerifyResponse>("/verify", { method: "POST", body: form });
}
