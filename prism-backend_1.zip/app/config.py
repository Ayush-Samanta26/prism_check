from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-5-5"

    search_provider: str = "tavily"
    tavily_api_key: str = ""
    brave_api_key: str = ""

    database_url: str = "sqlite:///./prism.db"

    ocr_langs: str = "eng+hin+ben"

    cors_origins: str = "http://localhost:3000"
    max_upload_mb: int = 8
    max_images: int = 4

    @property
    def cors_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
