import asyncio

from ..config import get_settings
from . import llm, ocr, search
from .llm import ImageInput
from .normalize import build_report, not_checkable_report

MAX_SOURCES = 8


async def run_verification(text: str, images: list[ImageInput]) -> dict:
    """OCR -> claim extraction -> web search -> evidence judgement -> structured report."""
    settings = get_settings()

    ocr_chunks = await asyncio.gather(*(asyncio.to_thread(ocr.extract_text, im.data) for im in images))
    ocr_text = "\n\n".join(c for c in ocr_chunks if c)

    extracted = await llm.extract_claim(text, ocr_text, images)
    claim = extracted["claim"]
    if not claim:
        return not_checkable_report(
            "PRISM could not find a factual claim to verify in this submission.",
            ocr_text,
            settings.anthropic_model,
            settings.search_provider,
        )

    queries = extracted["queries"] or [claim]
    batches = await asyncio.gather(*(search.search(q) for q in queries))

    sources: list[dict] = []
    seen: set[str] = set()
    # round-robin across queries so one query cannot crowd out the others
    for rank in range(max(len(b) for b in batches) if batches else 0):
        for batch in batches:
            if rank < len(batch) and batch[rank]["url"] not in seen:
                seen.add(batch[rank]["url"])
                sources.append(batch[rank])
    sources = sources[:MAX_SOURCES]

    judged = await llm.judge(claim, sources, images)
    report = build_report(
        judged,
        claim=claim,
        sources=[
            {"index": i, "title": s["title"], "url": s["url"], "published": s.get("published")}
            for i, s in enumerate(sources, 1)
        ],
        ocr_text=ocr_text,
        model=settings.anthropic_model,
        search_provider=settings.search_provider,
    )
    report["queries"] = queries
    return report
