import io
import logging

from PIL import Image

from ..config import get_settings

log = logging.getLogger("prism.ocr")


def extract_text(data: bytes) -> str:
    """OCR an image. Returns "" if OCR is unavailable; the vision model still sees the image."""
    try:
        import pytesseract
    except ImportError:
        log.warning("pytesseract not installed; skipping OCR")
        return ""

    try:
        img = Image.open(io.BytesIO(data)).convert("RGB")
    except Exception:
        return ""

    langs = get_settings().ocr_langs
    try:
        return pytesseract.image_to_string(img, lang=langs).strip()
    except pytesseract.TesseractNotFoundError:
        log.warning("tesseract binary not found; skipping OCR")
        return ""
    except pytesseract.TesseractError:
        # Most likely a missing language pack: retry with English only.
        try:
            return pytesseract.image_to_string(img, lang="eng").strip()
        except Exception:
            return ""
