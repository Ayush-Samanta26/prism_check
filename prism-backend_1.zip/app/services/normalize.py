"""Pure helpers (no third-party imports) for parsing and validating model output."""
import json
from datetime import datetime, timezone
from typing import Any

VERDICTS = ("TRUE", "MOSTLY_TRUE", "MIXED", "MOSTLY_FALSE", "FALSE", "UNVERIFIABLE")


def parse_json_object(text: str) -> dict:
    """Extract the first JSON object from a model reply. Raises ValueError if none."""
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end <= start:
        raise ValueError("no JSON object in model output")
    obj = json.loads(text[start : end + 1])
    if not isinstance(obj, dict):
        raise ValueError("model output JSON is not an object")
    return obj


def _cite(items: Any, sources: list[dict]) -> list[dict]:
    """Map the model's {source_index, note} items onto real retrieved sources.

    Indexes are 1-based. Anything pointing outside the retrieved set is dropped,
    so a citation can never reference a URL that search did not return.
    """
    out: list[dict] = []
    seen: set[int] = set()
    if not isinstance(items, list):
        return out
    for it in items:
        if not isinstance(it, dict):
            continue
        idx = it.get("source_index")
        if not isinstance(idx, int) or idx < 1 or idx > len(sources) or idx in seen:
            continue
        seen.add(idx)
        src = sources[idx - 1]
        out.append(
            {
                "index": idx,
                "title": src.get("title", ""),
                "url": src.get("url", ""),
                "published": src.get("published"),
                "note": str(it.get("note", "")).strip(),
            }
        )
    return out


def build_report(
    judged: dict,
    claim: str,
    sources: list[dict],
    ocr_text: str,
    model: str,
    search_provider: str,
) -> dict:
    verdict = str(judged.get("verdict", "")).upper()
    if verdict not in VERDICTS:
        verdict = "UNVERIFIABLE"

    try:
        confidence = float(judged.get("confidence", 0))
    except (TypeError, ValueError):
        confidence = 0.0
    confidence = max(0.0, min(1.0, confidence))

    supporting = _cite(judged.get("supporting"), sources)
    contradicting = _cite(judged.get("contradicting"), sources)

    limitations = [str(x).strip() for x in (judged.get("limitations") or []) if str(x).strip()]

    # Honesty guards: a definite verdict needs cited evidence behind it.
    if verdict != "UNVERIFIABLE" and not supporting and not contradicting:
        verdict = "UNVERIFIABLE"
        confidence = 0.0
        limitations.append("The model gave a verdict without citing any retrieved source, so it was downgraded.")
    if not sources:
        verdict = "UNVERIFIABLE"
        confidence = 0.0
        limitations.append("No web sources were retrieved for this claim.")

    return {
        "claim": claim,
        "verdict": verdict,
        "confidence": round(confidence, 2),
        "explanation": str(judged.get("explanation", "")).strip(),
        "supporting": supporting,
        "contradicting": contradicting,
        "sources": sources,
        "limitations": limitations,
        "ocr_text": ocr_text,
        "analyzed_at": datetime.now(timezone.utc).isoformat(),
        "models": {"llm": model, "search": search_provider},
    }


def not_checkable_report(reason: str, ocr_text: str, model: str, search_provider: str) -> dict:
    return {
        "claim": "",
        "verdict": "UNVERIFIABLE",
        "confidence": 0.0,
        "explanation": reason,
        "supporting": [],
        "contradicting": [],
        "sources": [],
        "limitations": ["No checkable factual claim was found in the submission."],
        "ocr_text": ocr_text,
        "analyzed_at": datetime.now(timezone.utc).isoformat(),
        "models": {"llm": model, "search": search_provider},
    }
