import base64
from dataclasses import dataclass

from ..config import get_settings
from ..errors import ServiceError
from .normalize import parse_json_object


@dataclass
class ImageInput:
    name: str
    media_type: str
    data: bytes


def _client():
    s = get_settings()
    if not s.anthropic_api_key:
        raise ServiceError("ANTHROPIC_API_KEY is not set on the server.", 503)
    import anthropic

    return anthropic.AsyncAnthropic(api_key=s.anthropic_api_key)


def _image_blocks(images: list[ImageInput]) -> list[dict]:
    return [
        {
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": im.media_type,
                "data": base64.b64encode(im.data).decode(),
            },
        }
        for im in images
    ]


async def _complete_json(system: str, text: str, images: list[ImageInput], max_tokens: int) -> dict:
    client = _client()
    content = _image_blocks(images) + [{"type": "text", "text": text}]
    try:
        msg = await client.messages.create(
            model=get_settings().anthropic_model,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": content}],
        )
    except ServiceError:
        raise
    except Exception as exc:  # network, auth, rate limit...
        raise ServiceError(f"The language model request failed: {exc.__class__.__name__}.") from exc

    reply = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
    try:
        return parse_json_object(reply)
    except ValueError as exc:
        raise ServiceError("The language model returned an unreadable answer. Please retry.") from exc


EXTRACT_SYSTEM = """You prepare claims for fact-checking.
Given a user's text and/or screenshots (plus OCR text from them), identify the single most
important, checkable factual claim being made. Ignore opinions, greetings and instructions.
If the submission is a screenshot of a post/article/message, the claim is what that content asserts.

Reply with ONLY a JSON object:
{
  "claim": "<one self-contained sentence, in the original language; empty string if nothing is checkable>",
  "language": "<ISO 639-1 code of the claim>",
  "queries": ["<up to 3 web search queries, in English unless the claim is local-language news, designed to find independent evidence for AND against the claim>"]
}"""


async def extract_claim(text: str, ocr_text: str, images: list[ImageInput]) -> dict:
    prompt = f"User text:\n{text or '(none)'}\n\nOCR text from screenshots:\n{ocr_text or '(none)'}"
    out = await _complete_json(EXTRACT_SYSTEM, prompt, images, 600)
    queries = [q.strip() for q in out.get("queries", []) if isinstance(q, str) and q.strip()][:3]
    return {
        "claim": str(out.get("claim", "")).strip(),
        "language": str(out.get("language", "en")).strip() or "en",
        "queries": queries,
    }


JUDGE_SYSTEM = """You are the evidence analyst for PRISM, a claim-verification tool.
You are given a claim and a numbered list of web sources that were just retrieved.

Rules:
- Judge ONLY from the numbered sources. Do not use outside knowledge to support a verdict, and never cite a source that is not in the list.
- Cite with 1-based source_index values. Put sources that back the claim in "supporting" and sources that undercut it in "contradicting", each with a one-sentence note on what that source says.
- If the sources are insufficient, off-topic, or only repeat the claim without independent evidence, the verdict is UNVERIFIABLE.
- Verdicts: TRUE, MOSTLY_TRUE, MIXED, MOSTLY_FALSE, FALSE, UNVERIFIABLE.
- Confidence is 0 to 1 and reflects the quality and agreement of the evidence, not how plausible the claim sounds.
- "limitations": real caveats (old sources, single source, paywalled snippets, ambiguity in the claim, screenshot not authenticated).
- Write "explanation" and the notes in the same language as the claim. Be concise and neutral.

Reply with ONLY a JSON object:
{
  "verdict": "...",
  "confidence": 0.0,
  "explanation": "<2-5 sentences>",
  "supporting": [{"source_index": 1, "note": "..."}],
  "contradicting": [{"source_index": 2, "note": "..."}],
  "limitations": ["..."]
}"""


async def judge(claim: str, sources: list[dict], images: list[ImageInput]) -> dict:
    listing = "\n\n".join(
        f"[{i}] {s['title']}\nURL: {s['url']}\nDate: {s.get('published') or 'unknown'}\n{(s.get('snippet') or '')[:1200]}"
        for i, s in enumerate(sources, 1)
    )
    prompt = f"Claim:\n{claim}\n\nSources:\n{listing or '(no sources were retrieved)'}"
    return await _complete_json(JUDGE_SYSTEM, prompt, images, 1500)
