import httpx

from ..config import get_settings
from ..errors import ServiceError

TIMEOUT = httpx.Timeout(20.0)


async def _tavily(query: str, limit: int) -> list[dict]:
    s = get_settings()
    if not s.tavily_api_key:
        raise ServiceError("TAVILY_API_KEY is not set on the server.", 503)
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        r = await client.post(
            "https://api.tavily.com/search",
            headers={"Authorization": f"Bearer {s.tavily_api_key}"},
            json={"query": query, "max_results": limit, "search_depth": "advanced"},
        )
    if r.status_code != 200:
        raise ServiceError(f"Tavily search failed ({r.status_code}).")
    return [
        {
            "title": x.get("title", ""),
            "url": x.get("url", ""),
            "snippet": x.get("content", ""),
            "published": x.get("published_date"),
        }
        for x in r.json().get("results", [])
        if x.get("url")
    ]


async def _brave(query: str, limit: int) -> list[dict]:
    s = get_settings()
    if not s.brave_api_key:
        raise ServiceError("BRAVE_API_KEY is not set on the server.", 503)
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        r = await client.get(
            "https://api.search.brave.com/res/v1/web/search",
            headers={"X-Subscription-Token": s.brave_api_key, "Accept": "application/json"},
            params={"q": query, "count": limit},
        )
    if r.status_code != 200:
        raise ServiceError(f"Brave search failed ({r.status_code}).")
    return [
        {
            "title": x.get("title", ""),
            "url": x.get("url", ""),
            "snippet": x.get("description", ""),
            "published": x.get("page_age") or x.get("age"),
        }
        for x in r.json().get("web", {}).get("results", [])
        if x.get("url")
    ]


async def search(query: str, limit: int = 6) -> list[dict]:
    provider = get_settings().search_provider.lower()
    if provider == "tavily":
        return await _tavily(query, limit)
    if provider == "brave":
        return await _brave(query, limit)
    raise ServiceError(f"Unknown SEARCH_PROVIDER '{provider}' (use tavily or brave).", 503)
