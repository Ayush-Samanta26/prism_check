class ServiceError(Exception):
    """A failure PRISM must surface to the user instead of papering over.

    PRISM never fabricates a verdict: if the LLM, search or any other
    required service is unavailable, the request fails with a clear message.
    """

    def __init__(self, message: str, status_code: int = 502):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
