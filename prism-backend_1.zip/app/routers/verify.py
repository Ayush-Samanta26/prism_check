import io
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from PIL import Image
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import get_db
from ..errors import ServiceError
from ..models import Chat, Message
from ..services.llm import ImageInput
from ..services.verify import run_verification
from .chats import serialize_message

router = APIRouter()

PIL_TO_MEDIA = {"PNG": "image/png", "JPEG": "image/jpeg", "WEBP": "image/webp", "GIF": "image/gif"}


async def _read_images(files: List[UploadFile]) -> List[ImageInput]:
    s = get_settings()
    if len(files) > s.max_images:
        raise HTTPException(400, f"At most {s.max_images} images per request.")
    limit = s.max_upload_mb * 1024 * 1024
    out: List[ImageInput] = []
    for f in files:
        data = await f.read()
        if not data:
            continue
        if len(data) > limit:
            raise HTTPException(413, f"'{f.filename}' is larger than {s.max_upload_mb} MB.")
        try:
            fmt = Image.open(io.BytesIO(data)).format
        except Exception:
            raise HTTPException(400, f"'{f.filename}' is not a readable image.")
        media = PIL_TO_MEDIA.get(fmt or "")
        if not media:
            raise HTTPException(400, f"'{f.filename}': only PNG, JPEG, WEBP and GIF are supported.")
        out.append(ImageInput(name=f.filename or "image", media_type=media, data=data))
    return out


@router.post("/verify")
async def verify(
    text: str = Form(""),
    chat_id: Optional[str] = Form(None),
    files: List[UploadFile] = File(default=[]),
    db: Session = Depends(get_db),
):
    text = text.strip()
    images = await _read_images(files)
    if not text and not images:
        raise HTTPException(400, "Provide a claim as text, an image, or both.")

    chat = db.get(Chat, chat_id) if chat_id else None
    if chat_id and not chat:
        raise HTTPException(404, "Chat not found")

    try:
        report = await run_verification(text, images)
    except ServiceError as exc:
        raise HTTPException(exc.status_code, exc.message)

    if not chat:
        title = (report.get("claim") or text or "Screenshot check")[:80]
        chat = Chat(title=title)
        db.add(chat)
        db.flush()

    user_msg = Message(
        chat_id=chat.id,
        role="user",
        content=text,
        attachments=[{"name": i.name, "media_type": i.media_type, "size": len(i.data)} for i in images],
    )
    assistant_msg = Message(chat_id=chat.id, role="assistant", content=report["explanation"], result=report)
    db.add_all([user_msg, assistant_msg])
    chat.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(user_msg)
    db.refresh(assistant_msg)

    return {
        "chat_id": chat.id,
        "title": chat.title,
        "user_message": serialize_message(user_msg),
        "assistant_message": serialize_message(assistant_msg),
    }
