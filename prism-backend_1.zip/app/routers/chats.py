from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Chat

router = APIRouter()


def serialize_message(m) -> dict:
    return {
        "id": m.id,
        "role": m.role,
        "content": m.content,
        "attachments": m.attachments or [],
        "result": m.result,
        "created_at": m.created_at.isoformat(),
    }


@router.get("/chats")
def list_chats(db: Session = Depends(get_db)):
    chats = db.scalars(select(Chat).order_by(Chat.updated_at.desc()).limit(200)).all()
    return [{"id": c.id, "title": c.title, "updated_at": c.updated_at.isoformat()} for c in chats]


@router.get("/chats/{chat_id}")
def get_chat(chat_id: str, db: Session = Depends(get_db)):
    chat = db.get(Chat, chat_id)
    if not chat:
        raise HTTPException(404, "Chat not found")
    return {
        "id": chat.id,
        "title": chat.title,
        "messages": [serialize_message(m) for m in chat.messages],
    }


@router.delete("/chats/{chat_id}", status_code=204)
def delete_chat(chat_id: str, db: Session = Depends(get_db)):
    chat = db.get(Chat, chat_id)
    if not chat:
        raise HTTPException(404, "Chat not found")
    db.delete(chat)
    db.commit()
