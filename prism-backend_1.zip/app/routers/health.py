from fastapi import APIRouter

from ..config import get_settings

router = APIRouter()


@router.get("/health")
def health():
    """Reports which required services are configured (never returns key values)."""
    s = get_settings()
    search_key = s.tavily_api_key if s.search_provider.lower() == "tavily" else s.brave_api_key
    return {
        "status": "ok",
        "llm_configured": bool(s.anthropic_api_key),
        "search_provider": s.search_provider,
        "search_configured": bool(search_key),
        "model": s.anthropic_model,
    }
