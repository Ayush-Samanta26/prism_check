import pytest

from app.services.normalize import build_report, not_checkable_report, parse_json_object

SOURCES = [
    {"index": 1, "title": "A", "url": "https://a.example", "published": "2026-01-01"},
    {"index": 2, "title": "B", "url": "https://b.example", "published": None},
]


def test_parse_json_with_surrounding_text():
    assert parse_json_object('Sure!\n```json\n{"a": 1}\n```') == {"a": 1}


def test_parse_json_rejects_garbage():
    with pytest.raises(ValueError):
        parse_json_object("no json here")


def test_citations_map_to_real_sources_only():
    judged = {
        "verdict": "TRUE",
        "confidence": 0.8,
        "explanation": "ok",
        "supporting": [{"source_index": 1, "note": "n"}, {"source_index": 9, "note": "bogus"}],
        "contradicting": [],
    }
    r = build_report(judged, "claim", SOURCES, "", "m", "tavily")
    assert [c["url"] for c in r["supporting"]] == ["https://a.example"]
    assert r["verdict"] == "TRUE"


def test_verdict_without_citations_is_downgraded():
    judged = {"verdict": "FALSE", "confidence": 0.9, "explanation": "x", "supporting": [], "contradicting": []}
    r = build_report(judged, "claim", SOURCES, "", "m", "tavily")
    assert r["verdict"] == "UNVERIFIABLE" and r["confidence"] == 0.0
    assert r["limitations"]


def test_no_sources_is_unverifiable():
    r = build_report({"verdict": "TRUE", "confidence": 1}, "claim", [], "", "m", "tavily")
    assert r["verdict"] == "UNVERIFIABLE"


def test_invalid_verdict_and_confidence_clamped():
    judged = {
        "verdict": "banana",
        "confidence": 7,
        "supporting": [{"source_index": 1, "note": ""}],
    }
    r = build_report(judged, "c", SOURCES, "", "m", "tavily")
    assert r["verdict"] == "UNVERIFIABLE"


def test_not_checkable():
    r = not_checkable_report("nothing", "", "m", "tavily")
    assert r["verdict"] == "UNVERIFIABLE" and r["claim"] == ""
